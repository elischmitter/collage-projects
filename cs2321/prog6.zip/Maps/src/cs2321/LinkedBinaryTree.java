package cs2321;

import java.util.Iterator;

import net.datastructures.*;

public class LinkedBinaryTree<E> implements BinaryTree<E> {
	protected static class Node<E> implements Position<E> {
		private E element;
		private Node<E> parent;
		private Node<E> left;
		private Node<E> right;

		/**
		 * @param element
		 * @param parent
		 * @param left
		 * @param right
		 */
		public Node(E element, Node<E> parent, Node<E> left, Node<E> right) {
			this.element = element;
			this.parent = parent;
			this.left = left;
			this.right = right;
		}

	
		@Override
		@TimeComplexity("O(1)")
		public E getElement() {
			return element;
		}
		@TimeComplexity("O(1)")
		public void setElement(E element) {
			this.element = element;
		}
		@TimeComplexity("O(1)")
		public Node<E> getParent() {
			return parent;
		}
		@TimeComplexity("O(1)")
		public void setParent(Node<E> parent) {
			this.parent = parent;
		}
		@TimeComplexity("O(1)")
		public Node<E> getLeft() {
			return left;
		}
		@TimeComplexity("O(1)")
		public void setLeft(Node<E> left) {
			this.left = left;
		}
		@TimeComplexity("O(1)")
		public Node<E> getRight() {
			return right;
		}
		@TimeComplexity("O(1)")
		public void setRight(Node<E> right) {
			this.right = right;
		}

	}
	@TimeComplexity("O(1)")
	protected Node<E> createNode(E e, Node<E> parent, Node<E> left, Node<E> right) {
		return new Node<E>(e, parent, left, right);
	}

	protected Node<E> root = null;
	private int size = 0;
	@TimeComplexity("O(1)")
	protected Node<E> val(Position<E> p) throws IllegalArgumentException {
		if (!(p instanceof Node)) {
			throw new IllegalArgumentException();
		}
		Node<E> node = (Node<E>) p;
		if (node.getParent() == node)
			throw new IllegalArgumentException();
		return node;
	}
	@TimeComplexity("O(1)")
	 public E set(Position<E> p, E e) throws IllegalArgumentException {
		    Node<E> node = val(p);
		    E temp = node.getElement();
		    node.setElement(e);
		    return temp;
		  }
	
	@Override
	@TimeComplexity("O(1)")
	public Position<E> root() {
		return root;
	}

	public LinkedBinaryTree() {

	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> parent(Position<E> p) throws IllegalArgumentException {
		Node<E> node = val(p);
		return node.getParent();
	}

	@Override
	@TimeComplexity("O(1)")
	public Iterable<Position<E>> children(Position<E> p) throws IllegalArgumentException {
		DoublyLinkedList<Position<E>> list = new DoublyLinkedList<>();
		if (left(p) != null)
			list.addLast(left(p));
		if (right(p) != null)
			list.addLast(right(p));
		return list;
	}

	@SuppressWarnings("unused")
	@Override
	/* count only direct child of the node, not further descendant. */
	@TimeComplexity("O(n)")
	public int numChildren(Position<E> p) throws IllegalArgumentException {
		int counter = 0;
		for (Position<E> i : children(p)) {
			counter++;
		}
		return counter;
	}

	@Override
	@TimeComplexity("O(n)")
	public boolean isInternal(Position<E> p) throws IllegalArgumentException {
		Node<E> n = val(p);
		return numChildren(n) > 0;
	}

	@Override
	@TimeComplexity("O(n)")
	public boolean isExternal(Position<E> p) throws IllegalArgumentException {
		Node<E> n = val(p);
		return numChildren(n) == 0;
	}

	@Override
	@TimeComplexity("O(1)")
	public boolean isRoot(Position<E> p) throws IllegalArgumentException {
		Node<E> n = val(p);
		return n.equals(root);
	}

	@Override
	@TimeComplexity("O(1)")
	public int size() {
		return size;
	}

	@Override
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		return size == 0;
	}

	private class treeIterator<E> implements Iterator<E> {
		private ArrayList<E> nodes;
		private int index = 0;
		@SuppressWarnings("unused")
		private Node<E> root;
		@TimeComplexity("O(1)")
		private void addN(Node<E> root) {
			if (root.getLeft() != null)
				addN(root.getLeft());
			nodes.addLast(root.getElement());
			if (root.getRight() != null)
				;
			addN(root.getRight());
		}
		@TimeComplexity("O(1)")
		treeIterator(Node<E> root) {
			this.root = root;
			addN(root);
		}

		@Override
		public boolean hasNext() {
			return index < nodes.size() - 1;
		}

		@Override
		public E next() {
			return nodes.get(++index);
		}

	}

	
	@Override
	public Iterator<E> iterator() {
		
		return new treeIterator<E>(root);
	}

	private class treeIteratorp implements Iterator<Position<E>> {
		private ArrayList<Position<E>> nodes;
		private int index = 0;
		@SuppressWarnings("unused")
		@TimeComplexity("O(1)")
		private Node<E> root;
		@TimeComplexity("O(1)")
		private void addN(Node<E> root) {
			if (root.getLeft() != null)
				addN(root.getLeft());
			nodes.addLast(root);
			if (root.getRight() != null)
				;
			addN(root.getRight());
		}
		@TimeComplexity("O(1)")
		treeIteratorp(Node<E> root) {
			this.root = root;
			addN(root);
		}

		@Override
		@TimeComplexity("O(1)")
		public boolean hasNext() {
			return index < nodes.size() - 1;
		}

		@Override
		@TimeComplexity("O(1)")
		public Position<E> next() {
			return nodes.get(++index);
		}
	} 
	private class treeIteratorpe implements Iterable<Position<E>>{
		Node<E> root;
		treeIteratorpe(Node<E> root) {
			this.root = root;
		}
		@Override
		@TimeComplexity("O(1)")
		public Iterator<Position<E>> iterator() {
			return new treeIteratorp(root);
		}
	}
	@Override
	@TimeComplexity("O(1)")
	public Iterable<Position<E>> positions() {
		return new treeIteratorpe(val(root));
	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> left(Position<E> p) throws IllegalArgumentException {
		Node<E> n =val(p);
		return n.getLeft();
	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> right(Position<E> p) throws IllegalArgumentException {
		Node<E> n =val(p);
		return n.getRight();
	}

	@Override
	@TimeComplexity("O(1)")
	public Position<E> sibling(Position<E> p) throws IllegalArgumentException {
		Node<E> n =val(p);
		Node<E> sibling= (n.getParent().getLeft().equals(n))?n.getParent().getRight():n.getParent().getLeft();
		return sibling;
	}

	/*
	 * creates a root for an empty tree, storing e as element, and returns the
	 * position of that root. An error occurs if tree is not empty.
	 */
	@TimeComplexity("O(1)")
	public Position<E> addRoot(E e) throws IllegalStateException {
		if(e==null) {
			return null;
		}
		if(root()==null) {
			root=createNode(e, null, null, null);
			size++;
			return root;
		}
		
		throw new IllegalStateException();
	}

	/*
	 * creates a new left child of Position p storing element e, return the left
	 * child's position. If p has a left child already, throw exception
	 * IllegalArgumentExeption.
	 */
	@TimeComplexity("O(1)")
	public Position<E> addLeft(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> n = val(p);
		if(n.getLeft()!=null) {
			throw new IllegalArgumentException();
		}
		Node<E> newN =createNode(e, n, null, null);
		n.setLeft(newN);
		size++;
		return newN;
	}

	/*
	 * creates a new right child of Position p storing element e, return the right
	 * child's position. If p has a right child already, throw exception
	 * IllegalArgumentExeption.
	 */
	@TimeComplexity("O(1)")
	public Position<E> addRight(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> n = val(p);
		if(n.getRight()!=null) {
			throw new IllegalArgumentException();
		}
		Node<E> newN =createNode(e, n, null, null);
		n.setRight(newN);
		size++;
		return newN;
	}

	/*
	 * Attach trees t1 and t2 as left and right subtrees of external Position. if p
	 * is not external, throw IllegalArgumentExeption.
	 */
	@TimeComplexity("O(1)")
	public void attach(Position<E> p, LinkedBinaryTree<E> t1, LinkedBinaryTree<E> t2) throws IllegalArgumentException {
		Node<E> node = val(p);
		if(isInternal(p)) {
			throw new IllegalArgumentException();
		}
		size+=t1.size()+t2.size();
		if(!t1.isEmpty()) {
			t1.root.setParent(node);
			node.setLeft(t1.root);
			t1.root=null;
			t1.size=0;
		}
		if(!t2.isEmpty()) {
			t2.root.setParent(node);
			node.setLeft(t2.root);
			t2.root=null;
			t2.size=0;
		}

	}
	@TimeComplexity("O(1)")
	public E remove(Position<E> p) {
		Node<E> node = val(p);
		if(numChildren(p)==2) {
			throw new IllegalArgumentException();
		}
		Node<E> child =(node.getLeft()!=null?node.getLeft():node.getRight());
		if(child != null) {
			child.setParent(node.getParent());
		}
		if(node ==root)
			root=child;
		else {
			Node<E> par = node.getParent();
			if(node == par.getLeft()) {
				par.setLeft(child);
			}else
				par.setRight(child);
		}
		size--;
		E temp =node.getElement();
		node.setElement(null);
		node.setLeft(null);
		node.setRight(null);
		node.setParent(node);
		return temp;
	}
}
