package cs2321;

import cs2321.AbstractMap.mapEntry;
import net.datastructures.*;

@SuppressWarnings("unused")
public class LookupTable<K extends Comparable<K>, V> extends AbstractMap<K,V> implements SortedMap<K, V> {
	
	/* Use Sorted ArrayList for the Underlying storage for the map of entries.
	 * 
	 */
	private ArrayList<mapEntry<K, V>> table; 

	@TimeComplexity("O(log n)")
	private Integer search(K i,int low, int high) {
		//recursive and binary serch is o(log n)
		if (high < low) return high + 1;
		int mid = (low+high)/2;
		if (table.get(mid).getKey().compareTo(i)==0) {
			return mid;
			}else if(table.get(mid).getKey().compareTo(i)>0) {
				 return search(i,low, mid-1);
			}else {
			return search(i, mid + 1, high);
		}
	}
	@TimeComplexity("O(log n)")
	private Integer search(K i) {
		return search(i,0, table.size()-1);
	}
	@TimeComplexity("O(1)")
	public LookupTable(){
		table =  new ArrayList<mapEntry<K, V>>();
	}

	@Override
	@TimeComplexity("O(1)")
	public int size() {
		return table.size();
	}

	@Override
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		return table.isEmpty();
	}

	@Override

	@TimeComplexity("O(log n)")
	public V get(K key) {
		Integer i = search(key);
		return (i == size() || key.compareTo(table.get(i).getKey())!=0)?null: table.get(i).getValue();
	}

	@Override
	@TimeComplexity("O(log n)")
	public V put(K key, V value) {
		int j = search(key);
		if(j<size() && key.equals(table.get(j).getKey())){
			V temp = table.get(j).getValue();
			table.get(j).setValue(value);
			return temp;
		}
		table.add(j,new mapEntry<K,V>(key,value));
		return null;
	}

	@Override

	@TimeComplexity("O(log n)")
	public V remove(K key) {
		Integer i = search(key);
		return (i == size() || key.compareTo(table.get(i).getKey())!=0)?null: table.remove(i).getValue();
		}


	@Override

	@TimeComplexity("O(n)")
	public Iterable<Entry<K, V>> entrySet() {
		return snapshot(0,null);
	}

	@Override
	@TimeComplexity("O(log n)")
	public Entry<K, V> firstEntry() {
		return safe(0);
	}

	@Override
	@TimeComplexity("O(log n)")
	public Entry<K, V> lastEntry() {
		return safe(table.size()-1);
	}
	@TimeComplexity("O(log n)")
	private Entry<K,V> safe(int j){
		//calls get
		if (j<0||j>=table.size()) return null;
		return table.get(j);
	}

	@Override
	@TimeComplexity("O(log n)")
	public Entry<K, V> ceilingEntry(K key)  {
		//calls search
		return safe(search(key));
	}

	@Override
	@TimeComplexity("O(log n)")
	public Entry<K, V> floorEntry(K key)  {
		//calls search
		int j =search(key);
		if(j==size()||!key.equals(table.get(j).getKey())) 
			j--;
		return safe(j);
	}

	@Override
	@TimeComplexity("O(log n)")
	public Entry<K, V> lowerEntry(K key) {
		//calls search;
		return safe(search(key)-1);
	}

	@Override
	@TimeComplexity("O(log n)")
	public Entry<K, V> higherEntry(K key) {
		//calls search
		int j =search(key);
		if(j<size()&&key.equals(table.get(j).getKey())) 
			j++;
		return safe(j);
	}
	@TimeComplexity("O(n)")
	private Iterable<Entry<K, V>> snapshot(int start, K stop){
		//loop n times
		ArrayList<Entry<K, V>> buffer = new ArrayList<>();
		int j = start;
		while(j<table.size()&& (stop==null || stop.compareTo(table.get(j).getKey())>0)) {
			buffer.addLast(table.get(j++));
			
		}
		return buffer;
	}

	@Override
	@TimeComplexity("O(n)")
	public Iterable<Entry<K, V>> subMap(K fromKey, K toKey){
		//snapshot is o(n)
		return snapshot(search(fromKey),toKey);
	}


}
