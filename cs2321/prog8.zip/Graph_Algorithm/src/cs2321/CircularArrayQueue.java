/**
 * 
 */
package cs2321;

import net.datastructures.Queue;

/**
 * The Class CircularArrayQueue.
 *
 * @param <E> the element type
 */

public class CircularArrayQueue<E> implements Queue<E> {
	
	/** The data array. */
	private E[] data;
	
	/** The size of the data stored. */
	private int size = 0;
	
	/** The front of the circular array. */
	private int front=0;
	
	/** The length of the array. */
	public int lenght =0;
	
	/**
	 * Instantiates a new circular array queue.
	 *
	 * @param queueSize the queue size
	 */
	@SuppressWarnings("unchecked")
	public CircularArrayQueue(int queueSize) {
		data = (E[]) new Object[queueSize];//safe cast
		lenght=queueSize;
	}
	
	/**
	 * Size .
	 *
	 * @return the size of the queue
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * Checks if is empty.
	 *
	 * @return true, if is empty
	 */
	@Override
	public boolean isEmpty() {
	return size==0;
	}

	/**
	 * Enqueue.
	 *
	 * @param e the element to be enqueued
	 */
	@Override
	public void enqueue(E e) {
		data[(front+size) % lenght ]= e; // make the position of the data loop
		size+=1;
		
	}

	/**
	 * return the first item of the queue.
	 *
	 * @return the e
	 */
	@Override
	public E first() {
		if (isEmpty())
			return null;
		return data[front];
	}

	/**
	 * Dequeue.
	 *
	 * @return the element that has been dequeued
	 */
	@Override
	public E dequeue() {
		if(isEmpty())//check if empty
			return null;
		E ret = data[front];
		data[front]=null;
		front=(front+1)%lenght; // makes fount can't be grater than length
		size-=1;
		return ret;
	}
    
}
