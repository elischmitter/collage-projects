package cs2321;

import net.datastructures.Stack;


public class DLLStack<E> implements Stack<E> {
	DoublyLinkedList<E> list = new DoublyLinkedList<>();
	
	@Override
	public int size() {
		return list.size();
	}

	@Override
	public boolean isEmpty() {
		return list.isEmpty();
	}

	@Override
	public void push(E e) {
		list.addFirst(e);		
	}

	@Override
	public E top() {
		return list.first().getElement();
	}

	@Override
	public E pop() {
		return list.removeFirst();
	}

}
