package cs2321;


import net.datastructures.Entry;
import net.datastructures.Map;
import net.datastructures.Position;
import java.util.Iterator;

public class UnorderedMap<K,V> extends AbstractMap<K,V> implements Map<K, V>{

	/* Use ArrayList or DoublyLinked list for the Underlying storage for the map of entries.
	 * Uncomment one of these two lines;
	 * private ArrayList<Entry<K,V>> arr; 
	 * private DoublyLinkedList<Entry<K,V>> arr;
	 */
	ArrayList<mapEntry<K, V>> arr = new ArrayList<>();

	@TimeComplexity("O(n)")
	private int fndIndex(K key) {
		//loop n times 
		int n = arr.size();
		for (int j=0; j < n; j++) 
			if (arr.get(j).getKey().equals(key)) 
				return j; 
		return -1; // special value denotes that key was not found 
	} 

	public UnorderedMap() {
		super();
	}

	@Override

	@TimeComplexity("O(1)")
	public int size() {
		return arr.size();
	}

	@Override

	@TimeComplexity("O(1)")	
	public boolean isEmpty() {
		return arr.isEmpty();
	}

	@Override

	@TimeComplexity("O(n)")
	public V get(K key) {
		int i = fndIndex(key);
		if(i==-1) return null;
		return arr.get(i).getValue();
	}

	@Override
	@TimeComplexity("O(n)")
	public V put(K key, V value) {
		int i = fndIndex(key);
		if(i==-1) {
			arr.addLast(new mapEntry<K,V>(key,value));
			return null;
		}
		V old = arr.get(i).getValue();
		arr.get(i).setValue(value);
		return old; 
	}

	@Override

	@TimeComplexity("O(n)")
	public V remove(K key) {
		int i = fndIndex(key);
		if(i==-1) {
			return null;
		}
		V old = arr.get(i).getValue();
		if(i != size()-1) {
			arr.set(i,arr.get(size()-1));
		}
		arr.remove(size()-1);
		return old;
	}

	@TimeComplexity("O(n)")
	private class EntryIterator implements Iterator<Entry<K,V>> {

		private int j=0; 
		public boolean hasNext() { return j < arr.size(); }
		public Entry<K,V> next() {
			return arr.get(j++); 
		}
		public void remove() { throw new UnsupportedOperationException(); 
		}
	}
	private class EntryIterable implements Iterable<Entry<K,V>> {
		public Iterator<Entry<K,V>> iterator() { return new EntryIterator();} 
	}
	@Override

	@TimeComplexity("O(n)")
	public Iterable<Entry<K,V>> entrySet() {
		return new EntryIterable();
	}
}
