package cs2321;

import net.datastructures.*;

/**
 * @author Ruihong Zhang
 * Reference textbook R14.16 P14.81 
 *
 */
public class Travel {
	AdjListGraph<String,Integer> graph = new AdjListGraph<>();
	HashMap<String,Vertex<String>> vmap= new HashMap<>();
	/**
	 * @param routes: Array of routes between cities. 
	 *                routes[i][0] and routes[i][1] represent the city names on both ends of the route. 
	 *                routes[i][2] represents the cost in string type. 
	 *                Hint: In Java, use Integer.valueOf to convert string to integer. 
	 */
	public Travel(String [][] routes) {
		for(String[] i : routes ) {
			Vertex<String> v1;
			Vertex<String> v2;
			if(vmap.get(i[0])==null) {
				v1 = graph.insertVertex(i[0]);
				vmap.put(i[0], v1);
			}else
				v1=vmap.get(i[0]);
			if(vmap.get(i[1])==null) {
				v2 = graph.insertVertex(i[1]);
				vmap.put(i[1], v2);
			}else
				v2=vmap.get(i[1]);
			graph.insertEdge(v1, v2, Integer.valueOf(i[2]));
			}
		}
	
	/**
	 * @param departure: the departure city name 
	 * @param destination: the destination city name
	 * @return Return the path from departure city to destination using Depth First Search algorithm. 
	 *         The path should be represented as ArrayList or DoublylinkedList of city names. 
	 *         The order of city names in the list should match order of the city names in the path.  
	 *         
	 * @IMPORTANT_NOTE: The outgoing edges should be traversed by the order of the city names stored in
	 *                 the opposite vertices. For example, if V has 3 outgoing edges as in the picture below,
	 *                           V
	 *                        /  |  \
	 *                       /   |    \
	 *                      B    A     F  
	 *              your algorithm below should visit the outgoing edges of V in the order of A,B,F.
	 *              This means you will need to create a helper function to sort the outgoing edges by 
	 *              the opposite city names.
	 *              	              
	 *              See the method sortedOutgoingEdges below. 
	 */
	public Iterable<String> DFSRoute(String departure, String destination ) {
		Vertex<String> v1 = vmap.get(departure);
		Vertex<String> v2 = vmap.get(destination);
		HashMap<Vertex<String>,Edge<Integer>> forest= new HashMap<>();
		HashMap<Vertex<String>,Integer> set = new HashMap<>();
		DoublyLinkedList<String> path = new DoublyLinkedList<>();
		DFS(v1,set,forest);
		if (forest.get(v2)!=null) {
			 Vertex<String> walk = v2;
			 path.addFirst(graph.validate(v2).getElement());
			 while (walk != v1) {
				 Edge<Integer> edge = forest.get(walk);
				 path.addFirst(graph.validate(graph.opposite(walk, edge)).getElement());
				 walk=graph.opposite(walk, edge);
			 }
		}
		return path;
	}
	private void DFS(Vertex<String> u,HashMap<Vertex<String>,Integer> set,HashMap<Vertex<String>,Edge<Integer>> forest) {
		set.put(u, 1);
		for(Edge<Integer>e:graph.outgoingEdges(u)) {
			Vertex<String> v=graph.opposite(u, e);
			if(set.get(v)==(null)) {
				forest.put(v, e);
				DFS(v,set,forest);
			}
		}
	}

	
	/**
	 * @param departure: the departure city name 
	 * @param destination: the destination city name
     * @return Return the path from departure city to destination using Breadth First Search algorithm. 
	 *         The path should be represented as ArrayList or DoublylinkedList of city names. 
	 *         The order of city names in the list should match order of the city names in the path.  
	 *         
	 * @IMPORTANT_NOTE: The outgoing edges should be traversed by the order of the city names stored in
	 *                 the opposite vertices. For example, if V has 3 outgoing edges as in the picture below,
	 *                           V
	 *                        /  |  \
	 *                       /   |    \
	 *                      B    A     F  
	 *              your algorithm below should visit the outgoing edges of V in the order of A,B,F.
	 *              This means you will need to create a helper function to sort the outgoing edges by 
	 *              the opposite city names.
	 *              	             
	 *              See the method sortedOutgoingEdges below. 
	 */
	
	public Iterable<String> BFSRoute(String departure, String destination ) {
		Vertex<String> v1 = vmap.get(departure);
		Vertex<String> v2 = vmap.get(destination);
		HashMap<Vertex<String>,Edge<Integer>> forest= new HashMap<>();
		HashMap<Vertex<String>,Integer> set = new HashMap<>();
		DoublyLinkedList<String> path = new DoublyLinkedList<>();
		BFS(v1,set,forest);
		if (forest.get(v2)!=null) {
			 Vertex<String> walk = v2;
			 path.addFirst(graph.validate(v2).getElement());
			 while (walk != v1) {
				 Edge<Integer> edge = forest.get(walk);
				 path.addFirst(graph.validate(graph.opposite(walk, edge)).getElement());
				 walk=graph.opposite(walk, edge);
			 }
		}
		return path;
	}
	private void BFS(Vertex<String> u,HashMap<Vertex<String>,Integer> set,HashMap<Vertex<String>,Edge<Integer>> forest) {
		CircularArrayQueue<Vertex<String>> q = new	CircularArrayQueue<>(graph.numVertices());
		set.put(u,1);
		q.enqueue(u);
		while(!q.isEmpty()) {
			Vertex<String> v = q.dequeue();
			for(Edge<Integer> e:graph.outgoingEdges(v)) {
				Vertex<String> p = graph.opposite(v, e);
				if (set.get(p)==null) {
					set.put(p, 1);
					forest.put(p, e);
					q.enqueue(p);
				}
				
				
			}
		}
	}
	
	/**
	 * @param departure: the departure city name 
	 * @param destination: the destination city name
	 * @param itinerary: an empty DoublylinkedList object will be passed in to the method. 
	 * 	       When a shorted path is found, the city names in the path should be added to the list in the order. 
	 * @return return the cost of the shortest path from departure to destination. 
	 *         
	 * @IMPORTANT_NOTE: The outgoing edges should be traversed by the order of the city names stored in
	 *                 the opposite vertices. For example, if V has 3 outgoing edges as in the picture below,
	 *                           V
	 *                        /  |  \
	 *                       /   |    \
	 *                      B    A     F  
	 *              your algorithm below should visit the outgoing edges of V in the order of A,B,F.
	 *              This means you will need to create a helper function to sort the outgoing edges by 
	 *              the opposite city names.
	 *              
	 *              See the method sortedOutgoingEdges below. 
	 */

	public int DijkstraRoute(String departure, String destination, DoublyLinkedList<String> itinerary ) {
		Vertex<String> v1 = vmap.get(departure);
		Vertex<String> v2 = vmap.get(destination);
		DoublyLinkedList<String> path = new DoublyLinkedList<>();
		Map<Vertex<String>, Edge<Integer>> pathsmap=spTree(v1,Dijkstra(v1));
		if (pathsmap.get(v1)!=null) {
			 Vertex<String> walk = v2;
			 path.addFirst(graph.validate(v2).getElement());
			 while (walk != v1) {
				 Edge<Integer> edge = pathsmap.get(walk);
				 path.addFirst((graph.opposite(walk, edge)).getElement());
				 walk=graph.opposite(walk, edge);
			 }
		}
		itinerary=path;
		return path.size();
		
	}
	
	private Map<Vertex<String>,Edge<Integer>> spTree( Vertex<String> s, Map<Vertex<String>,Integer> d) {
	    Map<Vertex<String>, Edge<Integer>> tree = new HashMap<>();
	    for (Vertex<String> v : d.keySet())
	      if (v != s)
	        for (Edge<Integer> e : graph.incomingEdges(v)) {   
	          Vertex<String> u = graph.opposite(v, e);
	          int wgt = e.getElement();
	          if (d.get(v) == d.get(u) + wgt)
	            tree.put(v, e);                            
	        }
	    return tree;
	  }
	private Map<Vertex<String>, Integer> Dijkstra(Vertex<String> src){
	Map<Vertex<String>,Integer> d = new HashMap<>();
	Map<Vertex<String>,Integer> cloud = new HashMap<>();
	HeapPQ<Integer,Vertex<String>> pq = new HeapPQ<>();
	Map<Vertex<String>, Entry<Integer,Vertex<String>>> pqTokens = new HashMap<>();
	for(Vertex<String> v: graph.vertices()) {
		if(v==src) {
			d.put(v, 0);
		}else {
			d.put(v, Integer.MAX_VALUE);
		}
		pqTokens.put(v,pq.insert(d.get(v), v));
	}
	while(!pq.isEmpty()) {
		Entry<Integer, Vertex<String>> entry = pq.removeMin();
	    int key = entry.getKey();
	    Vertex<String> u = entry.getValue();
	    cloud.put(u, key);                             
	    pqTokens.remove(u);  
	    for(Edge<Integer> e: sortedOutgoingEdges(u)) {
	    	Vertex<String> v = graph.opposite(u, e);
	    	if(cloud.get(v)==null) {
	    		int wgt = e.getElement();
	    		if(d.get(u)+wgt < d.get(v)){
	    			d.put(v, d.get(u)+wgt);
	    			pq.replaceKey(pqTokens.get(v), d.get(v));
	    		}
	    	}
	    }
	}
	return cloud;
	}
	

	/**
	 * I strongly recommend you to implement this method to return sorted outgoing edges for vertex V
	 * You may use any sorting algorithms, such as insert sort, selection sort, etc.
	 * 
	 * @param v: vertex v
	 * @return a list of edges ordered by edge's name
	 */

	
	  public Iterable<Edge<Integer>> sortedOutgoingEdges(Vertex<String> v) {
		  DoublyLinkedList<Edge<Integer>> list2=new DoublyLinkedList<Edge<Integer>>();
		  @SuppressWarnings("unchecked")
		Vertex<String>[] arr=(Vertex<String>[]) new Vertex[graph.outDegree(v)];
		  int i=0;
		  for(Edge<Integer> curr:graph.outgoingEdges(v)) {
			  arr[i]= graph.opposite(v,curr);
			  i++;
		  }
		  QuickSort sort =new QuickSort();
		  sort.sort(arr);
		  
		  for(int j=0;j<arr.length;j++) {
			  list2.addLast(graph.getEdge(arr[j],v));
		  }
		  return list2;
	 }
	 	 

}
