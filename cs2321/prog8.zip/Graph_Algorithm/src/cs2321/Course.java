package cs2321;

import net.datastructures.Edge;
import net.datastructures.Entry;
import net.datastructures.Graph;
import net.datastructures.Position;
import net.datastructures.PositionalList;
import net.datastructures.Vertex;

/**
 * @author Ruihong Zhang
 * Reference: Text book: R14.17 on page 678
 *
 */
public class Course {
	AdjListGraph<String,Integer> graph = new AdjListGraph<>(true);
	HashMap<String,Vertex<String>> vmap= new HashMap<>();
	/**
	 * @param courses: An array of course information. Each element in the array is also array:
	 * 				starts with the course name, followed by a list (0 or more) of prerequisite course names.
	 * 
	 */
	public Course(String courses[][]) {
		
		for(String[] i : courses ) {
			for(String s: i) {
				if(vmap.get(s)==null)
				vmap.put(s,graph.insertVertex(s));
			}
			int x=1;
			do{
				if(i.length>1) {
				graph.insertEdge(vmap.get(i[x]),vmap.get(i[0]),1);
				}
				x++;
			}while(x<i.length);
		}
	}
	public DoublyLinkedList<Edge<Integer>> MST(Graph<String,Integer> g) {
		DoublyLinkedList<Edge<Integer>> tree = new DoublyLinkedList<>();
	    HeapPQ<Integer, Edge<Integer>> pq = new HeapPQ<>();
	    Partition<Vertex<String>> forest = new Partition<>();
	    HashMap<Vertex<String>,Position<Vertex<String>>> positions = new HashMap<>();

	    for (Vertex<String> v : g.vertices())
	      positions.put(v, forest.makeCluster(v));

	    for (Edge<Integer> e : g.edges())
	      pq.insert(e.getElement(), e);

	    int size = g.numVertices();
	    while (tree.size() != size - 1 && !pq.isEmpty()) {
	      Entry<Integer, Edge<Integer>> entry = pq.removeMin();
	      Edge<Integer> edge = entry.getValue();
	      Vertex<String>[] endpoints = g.endVertices(edge);
	      Position<Vertex<String>> a = forest.find(positions.get(endpoints[0]));
	      Position<Vertex<String>> b = forest.find(positions.get(endpoints[1]));
	      if (a != b) {
	        tree.addLast(edge);
	        forest.union(a,b);
	      }
	    }

	    return tree;
	  }

	private class Partition<E> {
		private class Locator<E> implements Position<E> {
			public E element;
			public int size;
			public Locator<E> parent;

			public Locator(E elem) {
				element = elem;
				size = 1;
				parent = this;
			}

			@Override
			public E getElement() {
				return element;
			}
			
		    private boolean validate(Partition<E> universe) {
		        return Partition.this == universe;
		      }
		}

		private Locator<E> validate(Position<E> pos) {
			if (!(pos instanceof Locator))
				throw new IllegalArgumentException("Invalid position");
			Locator<E> loc = (Locator<E>) pos;
			if (!loc.validate(this))
				throw new IllegalArgumentException("Position does not belong to this structure");
			return loc;
		}
		public Position<E> makeCluster(E e) {
		    return new Locator<E>(e);
		  }

		  /**
		   * Finds the cluster containing the element identified by Position p
		   * and returns the Position of the cluster's leader.
		   */
		  public Position<E> find(Position<E> p) {
		    Locator<E> loc = validate(p);
		    if (loc.parent != loc)
		      loc.parent = (Locator<E>) find(loc.parent);   // overwrite parent after recursion
		    return loc.parent;
		  }

		  /** Merges the clusters containing elements with positions p and q (if distinct). */
		  public void union(Position<E> p, Position<E> q) {
		    Locator<E> a = (Locator<E>) find(p);
		    Locator<E> b = (Locator<E>) find(q);
		    if (a != b)
		      if (a.size > b.size) {
		        b.parent = a;
		        a.size += b.size;
		      } else {
		        a.parent = b;
		        b.size += a.size;
		      }
		  }
	}

	private int Semesterlist(DoublyLinkedList<Edge<Integer>> topo,String course){
		int i =1;
		for(Edge<Integer> e:topo) {
			Vertex<String> a[]=graph.endVertices(e);	
			if(vmap.get(course).equals(a[0])) {
				return i;
		}
			
			if (graph.inDegree(a[0])>=1) {
					i++;
			}
	
		}
		return i;
	
	}

	/**
	 * @param course
	 * @return find the earliest semester that the given course could be taken by a students after taking all the prerequisites. 
	 */
	public int whichSemester(String course) {
		
		int i =Semesterlist(MST(graph),course);
		return i;
	}
			
}
