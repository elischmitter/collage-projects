package cs2321;

import net.datastructures.*;

public class QuickSort {
	private void swap(Vertex<String>[]array,int i,int j) {
		Vertex<String> temp=array[i];
		array[i]=array[j];
		array[j]=temp;
	}
	private int Partiton(Vertex<String>[] array, int p, int r) {
		String x=array[r].getElement();
		int i = p-1;
		for(int j=p;j<r;j++) {
			if(array[j].getElement().compareTo(x)<0) {
				i=i+1;
				swap(array,i,j);
			}
		}
		swap(array,i+1,r);
		return i+1;
	}
	private void Qsort(Vertex<String>[] array, int p, int r) {
		if(p<r) {
			int q=Partiton(array,p,r);
			Qsort(array,p,q-1);
			Qsort(array,q+1,r);
		}
	}
	public void sort(Vertex<String>[] array) {
		Qsort(array,0,array.length-1);

	}
}
