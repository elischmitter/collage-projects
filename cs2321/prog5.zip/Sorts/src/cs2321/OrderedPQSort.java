package cs2321;

import net.datastructures.PriorityQueue;

public class OrderedPQSort<K extends Comparable<K>> extends PQSort<K> implements Sorter<K>  {
	@Override
	@TimeComplexity("O(n^2)")
	public void sort(K[] array) {
		//two loops of n that loops n times.
		OrderedPQ<K,K> pq = new OrderedPQ<>(); 
		PQSort<K> pqsort = new PQSort<>();
		pqsort.sort(array, pq);
			
	}
}
