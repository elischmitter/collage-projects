package cs2321;

public class HeapPQSort<K extends Comparable<K>> extends PQSort<K> implements Sorter<K> {
	@TimeComplexity("O(n log n )")
	public void sort(K[] array) {
		//The add n items to the PQ with takes log n to run
		HeapPQ<K,K> pq = new HeapPQ<>(); 
		PQSort<K> pqsort = new PQSort<>();
		pqsort.sort(array, pq);	
	}

}
