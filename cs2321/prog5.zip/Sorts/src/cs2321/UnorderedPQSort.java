package cs2321;

public class UnorderedPQSort<K extends Comparable<K>> extends PQSort<K> implements Sorter<K>  {
	@Override
	@TimeComplexity("O(n^2)")
	public void sort(K[] array) {
		//two loops of n that loops n times.
		UnorderedPQ<K,K> pq = new UnorderedPQ<>();
		PQSort<K> pqsort = new PQSort<>();
		pqsort.sort(array, pq);
	}

}
