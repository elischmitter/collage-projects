package cs2321;

public class MergeSort<E extends Comparable<E>> implements Sorter<E> {
	
	@TimeComplexity("O(log n)")
	private void merge(E[] a1,E[] a2,E[] array) {
		int n1=a1.length;
		int n2=a2.length;
		int i=0, j=0, k=0;
		while(i< n1 && j< n2) {
			if(a1[i].compareTo(a2[j])<=0) {
				array[k++]=a1[i++];
			}
			else {
				array[k++]=a2[j++];
			}
		}
		while(i<n1) {
			array[k++]=a1[i++];
		}
		while(j<n2) {
			array[k++]=a2[j++];
		}
	}
	@TimeComplexity("O(n log n )")
	public void sort(E[] array) {
		if(array.length<2) {
			return;
		}
		@SuppressWarnings("unchecked")
		E[] a1=(E[])new Comparable[array.length/2];//safe cast 
		@SuppressWarnings("unchecked")
		E[] a2=(E[])new Comparable[array.length-a1.length];//safe cast

		int i =0;
		for(;i<array.length/2;i++) {
			a1[i]=array[i];
		}
		int j = 0;

		for(;i<array.length;i++) {
			a2[j]=array[i];
			j++;
		}

		sort(a1);
		sort(a2);
		merge(a1,a2,array);
	}
}

