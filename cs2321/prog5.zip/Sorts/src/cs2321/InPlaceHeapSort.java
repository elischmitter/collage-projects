package cs2321;

public class InPlaceHeapSort<K extends Comparable<K>> implements Sorter<K> {
	int heapSize;
	@TimeComplexity("O(1)")
	private int left(int i) {
		return 2*i+1;
	}
	@TimeComplexity("O(1)")
	private int right(int i) {
		return 2*i+2;
	}
	
	@TimeComplexity("O(1)")
	private void swap(K[] array,int i,int j) {
		K temp = array[i];
		array[i] = array[j];
		array[j]=temp;
		}
	@TimeComplexity("O(n)")
	private void maxHeapify(K[] arr,int i) {
	 int max = i;
	 int l = left (i);
	 int r = right(i);
	 if (l <heapSize && arr[l].compareTo(arr[max])> 0) {
		 max = l;
	 }

	 if (r < heapSize && arr[r].compareTo(arr[max])> 0) {
		 max = r;
	 }
	 
	 if(max!=i) {
		 swap(arr,i, max);
		 maxHeapify(arr,max);
	 }
	}
	@TimeComplexity("O(n)")
	private void buildHeap(K[] arr) {
		heapSize=arr.length;
		for(int i=arr.length/2;i>=0;i--) {
			maxHeapify(arr,i);
		}
	}
	/**
	 * sort - Perform an in-place heap sort
	 * @param array - Array to sort
	 */
	@Override
	@TimeComplexity("O(n log n)")
	public void sort(K[] array) {
		// loops n log n times 
		buildHeap(array);
		for(int i = array.length-1; i>=1;i--) {
			swap(array,0,i);
			heapSize--;
			maxHeapify(array,0);
		}
	}

}
