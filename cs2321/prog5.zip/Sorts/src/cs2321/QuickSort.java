package cs2321;

public class QuickSort<E extends Comparable<E>> implements Sorter<E> {
	private void swap(E[]array,int i,int j) {
		E temp=array[i];
		array[i]=array[j];
		array[j]=temp;
	}
	private int Partiton(E[] array, int p, int r) {
		E x=array[r];
		int i = p-1;
		for(int j=p;j<r;j++) {
			if(array[j].compareTo(x)<0) {
				i=i+1;
				swap(array,i,j);
			}
		}
		swap(array,i+1,r);
		return i+1;
	}
	private void Qsort(E[] array, int p, int r) {
		if(p<r) {
			int q=Partiton(array,p,r);
			Qsort(array,p,q-1);
			Qsort(array,q+1,r);
		}
	}
	public void sort(E[] array) {
		Qsort(array,0,array.length-1);

	}
}
