package cs2321;

import java.util.Comparator;

import net.datastructures.*;

/**
 * A PriorityQueue based on an Unordered Doubly Linked List. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 *
 * @author 
 * @param <K> the key type
 * @param <V> the value type
 */

public class UnorderedPQ<K,V> implements PriorityQueue<K,V> {
	
	/** The Comparator */
	private Comparator<K> comp;
	
	/** The list where all the data is stored . */
	private DoublyLinkedList<Entry<K,V>> list = new DoublyLinkedList<>();
	
	/**
	 * Find the minimum value.
	 *
	 * @return the position
	 */
	@TimeComplexity("O(n)")
	private Position<Entry<K,V>> findMin() {
		//loops n times looking for the min
		Position<Entry<K,V>> small = list.first();
		for(Position<Entry<K, V>> i:list.positions()) {
			if(comp.compare(small.getElement().getKey(),i.getElement().getKey())>0) {
				small=i;
			}
		}
		return small;
	}
	
	/**
	 * Checks the key to see if its valid.
	 *
	 * @param k the key
	 * @return true, if successful
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	@TimeComplexity("O(1)")
	private boolean checkKey(K k) throws  IllegalArgumentException {
		try {
			return(comp.compare(k, k)==0);
		}catch(ClassCastException e){
			throw new IllegalArgumentException();
		}
	}

	
	/**
	 * Instantiates a new unordered PQ.
	 */
	public UnorderedPQ() {
		this(new DefaultComparator<K>());
	}

	
	/**
	 * Instantiates a new unordered PQ.
	 *
	 * @param c the comparator 
	 */
	public UnorderedPQ(Comparator<K> c) {
			comp=c;
	}

	/**
	 * returns the size of the PQ.
	 *
	 * @return the size of the PQ
	 */
	@Override
	@TimeComplexity("O(1)")
	public int size() {
		return list.size();
	}

	/**
	 * Checks if is empty.
	 *
	 * @return true, if is empty
	 */
	@Override
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		return list.isEmpty();
	}

	/**
	 * Insert.
	 *
	 * @param key the key
	 * @param value the value
	 * @return the entry
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	@Override
	@TimeComplexity("O(1)")
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
	//constant time because all the function calls are of time O("1")
		checkKey(key);
		Entry<K,V> newE = new PQEntry<>(key,value);
		list.addLast(newE);
		return newE;
	}

	/**
	 * Min.
	 *
	 * @return the entry
	 */
	@Override
	@TimeComplexity("O(n)")
	public Entry<K, V> min() {
	//has n time because of the findMin function call
		if(isEmpty()) {
			return null;
		}
		return findMin().getElement();
	}

	/**
	 * Removes the min value.
	 *
	 * @return the entry
	 */
	@Override  
	@TimeComplexity("O(n)")
	public Entry<K, V> removeMin() {
		//has n time because of the findMin function call
		if (isEmpty()) {
			return null;
		}
		return list.remove(findMin());
	}
}
