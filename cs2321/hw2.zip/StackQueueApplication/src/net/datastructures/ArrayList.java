package net.datastructures;

import java.util.Iterator;

import net.datastructures.List;

/**
 * The Class ArrayList.
 *
 * @param <E> the element type
 */
public class ArrayList<E> implements List<E> {
	
	/** The cap. */
	private int cap;// Capacity of the array
	
	/** The size. */
	private int size = 0;// size of the data in the array
	
	/** The arr. */
	private E[] arr;// the array it self

	/**
	 * Checkbound.
	 *
	 * @param i val to check if in bounds
	 * @param k max bound to check
	 */
	void checkbound(int i, int k) {
		if (i >= k || i < 0) {
			throw new IndexOutOfBoundsException();
		}
	}

	/**
	 * Check to see if number is in the bounds of the array 
	 *	
	 * @param i t
	 */
	private void checkbound(int i) {
		checkbound(i, size);
	}

	/**
	 * Resize the array by two.
	 */
	private void resize() {
		E[] temp = (E[]) new Object[cap * 2];
		cap = cap * 2;
		for (int k = 0; k < size; k++) {
			temp[k] = arr[k];
		}
		arr = temp;
	}

	/**
	 * Instantiates a new array list with default values.
	 */
	public ArrayList() {
		cap = 16;
		arr = (E[]) new Object[cap];//safe cast
	}

	/**
	 * Instantiates a new array list.
	 *
	 * @param cap the cap
	 */
	public ArrayList(int cap) {
		this.cap = cap;
		arr = (E[]) new Object[this.cap];// the cast is safe
	}

	/**
	 * Size.
	 *
	 * @return the size of the data
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * Checks if is empty.
	 *
	 * @return true, if is empty
	 */
	@Override
	public boolean isEmpty() {
		return size() == 0;
	}

	/**
	 * Gets the.
	 *
	 * @param i the i
	 * @return the e
	 * @throws IndexOutOfBoundsException the index out of bounds exception
	 */
	@Override
	public E get(int i) throws IndexOutOfBoundsException {
		checkbound(i);
		return arr[i];
	}

	/**
	 * Sets the.
	 *
	 * @param i the i
	 * @param e the e
	 * @return the e
	 * @throws IndexOutOfBoundsException the index out of bounds exception
	 */
	@Override
	public E set(int i, E e) throws IndexOutOfBoundsException {
		checkbound(i);
		E temp = arr[i];
		arr[i] = e;
		return temp;
	}

	/**
	 * Adds the.
	 *
	 * @param i the i
	 * @param e the e
	 * @throws IndexOutOfBoundsException the index out of bounds exception
	 */
	@Override
	public void add(int i, E e) throws IndexOutOfBoundsException {
		checkbound(i, size + 1);
		if (size >= cap)
			resize();

		for (int x = size - 1; x >= i; x--) {
			arr[x + 1] = arr[x];
		}
		arr[i] = e;
		size++;
	}

	/**
	 * Removes the.
	 *
	 * @param i the i
	 * @return the e
	 * @throws IndexOutOfBoundsException the index out of bounds exception
	 */
	@Override
	public E remove(int i) throws IndexOutOfBoundsException {
		checkbound(i);
		E temp = arr[i];
		for (int x = i; x < size; x++) {
			arr[x] = arr[x + 1];
		}
		arr[size-1]=null;
		size--;
		return temp;
	}

	/**
	 * Iterator.
	 *
	 * @return the iterator
	 */
	@Override
	public Iterator<E> iterator() {
		return new Iterator<E>() {
			private int pos = 0;

			@Override
			public boolean hasNext() {
				return size > pos;
			}

			@Override
			public E next() {
				return get(pos++);
			}

			@Override
			public void remove() {
				ArrayList.this.remove(pos);
			}
		};
	}

	/**
	 * Adds the first.
	 *
	 * @param e the e
	 */
	public void addFirst(E e) {
		add(0, e);
	}

	/**
	 * Adds the last.
	 *
	 * @param e the e
	 */
	public void addLast(E e) {
		add(size, e);
	}

	/**
	 * Removes the first.
	 *
	 * @return the e
	 * @throws IndexOutOfBoundsException the index out of bounds exception
	 */
	public E removeFirst() throws IndexOutOfBoundsException {
		return remove(0);
	}

	/**
	 * Removes the last.
	 *
	 * @return the e
	 * @throws IndexOutOfBoundsException the index out of bounds exception
	 */
	public E removeLast() throws IndexOutOfBoundsException {
		return remove(size - 1);
	}

	// Return the capacity of array, not the number of elements.
	// Notes: The initial capacity is 16. When the array is full, the array should
	/**
	 * Capacity.
	 *
	 * @return the int
	 */
	// be doubled.
	public int capacity() {
		return cap;
	}

}
