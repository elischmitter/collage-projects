package cs2321;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("unused")
public class PostfixExpressionTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testEvaluate1() {	
		org.junit.Assert.assertEquals( PostfixExpression.evaluate("1 2 * "),2);
	}
	
	@Test
	public void testEvaluate2() {
		org.junit.Assert.assertEquals( PostfixExpression.evaluate("1 2 + 3 - 2 + 5 6 * 4 * 3 * 2 * +"),722);
	}
	
	@Test
	public void testEvaluate3() {
		org.junit.Assert.assertEquals( PostfixExpression.evaluate("1"),1);
	}
	
	@Test
	public void testEvaluate4() {
		org.junit.Assert.assertEquals( PostfixExpression.evaluate("4 4 + 4 + 4 + 4 + 4 + 4 +"),28);
	}
	
	@Test
	public void testEvaluate5() {
		org.junit.Assert.assertEquals( PostfixExpression.evaluate("1 3 + 4 / 3 + 4 * 2 * 4 4 4 + + +"),44);
	}
	
	@Test
	public void testEvaluate6() {
		org.junit.Assert.assertEquals( PostfixExpression.evaluate("347 32 - 1 77 * +"),392);
	}
	
	@Test
	public void testEvaluate7() {
		org.junit.Assert.assertEquals( PostfixExpression.evaluate("10 5 / 5 +"),7);
	}
	
	@Test
	public void testEvaluate8() {
		org.junit.Assert.assertEquals( PostfixExpression.evaluate("44 4 - 33 + 22 2 / +"),84);
	}

}
