package cs2321;

public class PostfixExpression {
	
	/**
	 * Evaluate a postfix expression. 
	 * Postfix expression notation has operands first, following by the operations.
	 * For example:
	 *    13 5 *           is same as 13 * 5 
	 *    4 20 5 + * 6 -   is same as 4 * (20 + 5) - 6  
	 *    
	 * In this homework, expression in the argument only contains
	 *     integer, +, -, *, / and a space between every number and operation. 
	 * You may assume the result will be integer as well. 
	 * 
	 * @param exp The postfix expression
	 * @return the result of the expression
	 */
	public static int evaluate(String exp) {
		
		String[] exparr=exp.split(" ");
		DLLStack<Integer> stack = new DLLStack<>();
		for(int i=0; i <exparr.length;i++) {
			String s = exparr[i];
			if(Character.isDigit(s.charAt(0))) {
				stack.push(Integer.parseInt(s));
			}else { 
				int v1 = stack.pop();
				int v2 = stack.pop();
				switch(s.charAt(0)) {
				case '+':
					stack.push(v2+v1);
					break;
				case '-':
					stack.push(v2-v1);
					break;
				case '*':
					stack.push(v2*v1);
					break;
				case '/':
					stack.push(v2/v1);
					break;
				}
			}
		}  
		return stack.pop();
	}
				
	
}
