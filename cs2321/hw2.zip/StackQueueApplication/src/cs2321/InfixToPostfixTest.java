package cs2321;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("unused")
public class InfixToPostfixTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testConvert1() {
		//1 * 2
		String s= InfixToPostfix.convert("1 * 2");
		org.junit.Assert.assertEquals("1 2 *",s);
	}
	
	@Test
	public void testConvert2() {
		String s= InfixToPostfix.convert("-1 * ( 3 + 4 )");
		org.junit.Assert.assertEquals("-1 3 4 + *",s);
	}

	@Test
	public void testConvert3() {
		String s= InfixToPostfix.convert("1 * ( ( ( 3 / 4 + 7 ) ) * 4 )");
		org.junit.Assert.assertEquals("1 3 4 / 7 + 4 * *",s);	}
	
	@Test
	public void testConvert4() {
		String s= InfixToPostfix.convert("324 * 4 / ( 2 + 4 )");
		org.junit.Assert.assertEquals("324 4 * 2 4 + /",s);	
	}
	
	@Test
	public void testConvert5() {
		String s= InfixToPostfix.convert("1");
		org.junit.Assert.assertEquals("1",s);
	}
	
	@Test
	public void testConvert6() {  
		String s= InfixToPostfix.convert("");
		org.junit.Assert.assertEquals("",s);
	}
	
	@Test
	public void testConvert7() {
		String s= InfixToPostfix.convert("1 + 2 - 3 + 4 / 5 * 6");
		org.junit.Assert.assertEquals("1 2 + 3 - 4 5 / 6 * +",s);
	}
	
	@Test
	public void testConvert8() {
		String s= InfixToPostfix.convert("1 + 2 - 3 + 2 + 5 * 6 * 4 * 3 * 2 ");
		org.junit.Assert.assertEquals("1 2 + 3 - 2 + 5 6 * 4 * 3 * 2 * +",s);
	}
}
