package cs2321;

import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.Before;
import org.junit.Test;

import net.datastructures.Position;

@SuppressWarnings("unused")
public class JosephusTest {
	String[] people= {"1","2","3","4","5"};
	Josephus joe = new Josephus();
	
	@Before
	public void setUp() throws Exception {

	}
	private boolean isEq(DoublyLinkedList<String> x,DoublyLinkedList<String>  y) {
		if (x.size()!=y.size()) {			
			return false;
			}
		Position<String> pos1 = x.first();
		Position<String> pos2 = y.first();
		for(int i =0; i<x.size();i++) {
			if(!pos1.getElement().equals(pos2.getElement())){
				return false;
			}
			pos1=x.after(pos1);
			pos2=x.after(pos2);
		}	
		return true;
	}
	@Test
	public void testOrder1() {
		DoublyLinkedList<String> goal= new DoublyLinkedList<>();
		goal.addLast("1");
		goal.addLast("2");
		goal.addLast("3");
		goal.addLast("4");
		goal.addLast("5");
		DoublyLinkedList<String> dead= joe.order(people,1);
		org.junit.Assert.assertTrue(isEq(dead,goal));
	}

	@Test
	public void testOrder2() {
		DoublyLinkedList<String> goal= new DoublyLinkedList<>();
		goal.addLast("2");
		goal.addLast("4");
		goal.addLast("1");
		goal.addLast("5");
		goal.addLast("3");
		DoublyLinkedList<String> dead= joe.order(people,2);
		org.junit.Assert.assertTrue(isEq(dead,goal));
	}

	@Test
	public void testOrder3() {
		DoublyLinkedList<String> goal= new DoublyLinkedList<>();
		goal.addLast("3");
		goal.addLast("2");
		goal.addLast("5");
		goal.addLast("4");
		goal.addLast("1");
		DoublyLinkedList<String> dead= joe.order(people,8);
		org.junit.Assert.assertTrue(isEq(dead,goal));
	}

	@Test
	public void testOrder4() {
		DoublyLinkedList<String> goal= new DoublyLinkedList<>();
		goal.addLast("4");
		goal.addLast("2");
		goal.addLast("1");
		goal.addLast("3");
		goal.addLast("5");
		DoublyLinkedList<String> dead= joe.order(people,999999);
		org.junit.Assert.assertTrue(isEq(dead,goal));
		}

}
