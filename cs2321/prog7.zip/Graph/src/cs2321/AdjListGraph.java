package cs2321;

import net.datastructures.*;

/*
 * Implement Graph interface. A graph can be declared as either directed or undirected.
 * In the case of an undirected graph, methods outgoingEdges and incomingEdges return the same collection,
 * and outDegree and inDegree return the same value.
 * 
 * @author CS2321 Instructor
 */
public class AdjListGraph<V, E> implements Graph<V, E> {
	private boolean directed;
	private PositionalList<Vertex<V>> vertices = new DoublyLinkedList<>();
	private PositionalList<Edge<E>> edges = new DoublyLinkedList<>();
	 
	@SuppressWarnings("hiding")
	private class InnerVertex<V> implements Vertex<V> {
		private V elem;
		private Position<Vertex<V>> pos;
		private Map<Vertex<V>, Edge<E>> outgoing, incoming;
		
		public InnerVertex(V elem, boolean graphIsDirected) { 
			this.elem=elem;
			outgoing = new HashMap<>();
			if(graphIsDirected) {
				incoming=new HashMap<>();
			}else {
			incoming=outgoing;
			}
		}
		@TimeComplexity("O(1)")
	    public void setElem(V elem) {
			this.elem = elem;
		}
		@TimeComplexity("O(1)")
		public boolean validate(Graph<V,E> graph) {
	        return (AdjListGraph.this == graph && pos != null);
	      }
		@TimeComplexity("O(1)")
		public V getElement() {
			 return elem; 
		}
		@TimeComplexity("O(1)")
		public Position<Vertex<V>> getPos() {
			return pos;
		}
		@TimeComplexity("O(1)")
		public void setPos(Position<Vertex<V>> pos) {
			this.pos = pos;
		}
		@TimeComplexity("O(1)")
		public Map<Vertex<V>, Edge<E>> getOutgoing() {
			return outgoing;
		}
		@TimeComplexity("O(1)")
		public Map<Vertex<V>, Edge<E>> getIncoming() {
			return incoming;
		}
	}
	@SuppressWarnings("hiding")
	private class InnerEdge<E> implements Edge<E> {
	    private E element;
	    private Position<Edge<E>> pos;
	    private Vertex<V>[] enendpoints;
		/**
		 * @param element
		 * @param pos
		 * @param end
		 */
	    
		@SuppressWarnings("unchecked")
		public InnerEdge(Vertex<V> one, Vertex<V> two,E element) {
			this.element = element;
			enendpoints= (Vertex<V>[])new Vertex[] {one,two};//safe cast
		}
		
		public void setElement(E element) {
			this.element = element;
		}

		@TimeComplexity("O(1)")
		public E getElement() {
			return element;
		}
		@TimeComplexity("O(1)")
		public Vertex<V>[] GetEndpoints() {
			return enendpoints;
		}
		@TimeComplexity("O(1)")
	    public Position<Edge<E>> getPos() {
			return pos;
		}
		@TimeComplexity("O(1)")
		public void setPos(Position<Edge<E>> pos) {
			this.pos = pos;
		}
		@TimeComplexity("O(1)")
		public boolean validate(AdjListGraph<V, E> adjListGraph) {
	        return (AdjListGraph.this == adjListGraph && pos != null);
	      }
	}
	@TimeComplexity("O(1)")
	private InnerVertex<V> validate(Vertex<V> v) {
		//all calls are O(1) and there are no loops
		if(!(v instanceof InnerVertex)) {
			throw new IllegalArgumentException();
		}
		InnerVertex<V> vert=(InnerVertex<V>)v;//safe cast

		return vert;
	}
	@TimeComplexity("O(1)")
	private InnerEdge<E> validate(Edge<E> e) {
		//all calls are O(1) and there are no loops
		if(!(e instanceof InnerEdge)) {
			throw new IllegalArgumentException();
		}
		InnerEdge<E> edge=(InnerEdge<E>)e;
		if(!edge.validate(this)) {
			throw new  IllegalArgumentException();
		}
		return edge;
	}
	
	public AdjListGraph(boolean directed) {
		this.directed=directed; 
	}

	public AdjListGraph() {
		this(false);
		}


	/* (non-Javadoc)
	 * @see net.datastructures.Graph#edges()
	 */
	@TimeComplexity("O(1)")
	public Iterable<Edge<E>> edges() {
		return edges;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#endVertices(net.datastructures.Edge)
	 */
	@TimeComplexity("O(1)")
	public Vertex<V>[] endVertices(Edge<E> e) throws IllegalArgumentException {
		//all calls are O(1) and there are no loops
		InnerEdge<E> edge = validate(e);
		return edge.GetEndpoints();
	}


	/* (non-Javadoc)
	 * @see net.datastructures.Graph#insertEdge(net.datastructures.Vertex, net.datastructures.Vertex, java.lang.Object)
	 */
	@TimeComplexity("O(1)")
	public Edge<E> insertEdge(Vertex<V> u, Vertex<V> v, E o)
			throws IllegalArgumentException {
		//all calls are O(1) and there are no loops
		if(getEdge(u,v)==null) {//see if there is already a node here.
			InnerEdge<E> e = new InnerEdge<>(u,v,o);
			e.setPos(edges.addLast(e));
		    InnerVertex<V> origin = validate(u);
		    InnerVertex<V> dest = validate(v);
		    origin.getOutgoing().put(v, e);
		    dest.getIncoming().put(u, e);
		    return e;
		}else 
			throw new IllegalArgumentException();
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#insertVertex(java.lang.Object)
	 */
	@TimeComplexity("O(1)")
	public Vertex<V> insertVertex(V o) {
		//all calls are O(1) and there are no loops
		InnerVertex<V> v = new InnerVertex<>(o,directed);
		v.setPos(vertices.addLast(v));
		return v;
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#numEdges()
	 */
	@TimeComplexity("O(1)")
	public int numEdges() {
		return edges.size();
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#numVertices()
	 */
	@TimeComplexity("O(1)")
	public int numVertices() {
		return vertices.size();
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#opposite(net.datastructures.Vertex, net.datastructures.Edge)
	 */
	@TimeComplexity("O(1)")
	public Vertex<V> opposite(Vertex<V> v, Edge<E> e)
			throws IllegalArgumentException {
		//all calls are O(1) and there are no loops
		InnerEdge<E> edge = validate(e);
		Vertex<V>[] endpoints = edge.GetEndpoints();
		if (endpoints[0]==v)
			return endpoints[1];
		else if((endpoints[1]==v))
			return endpoints[0];
		else
			throw new IllegalArgumentException();
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#removeEdge(net.datastructures.Edge)
	 */
	@TimeComplexity("O(1)")
	public void removeEdge(Edge<E> e) throws IllegalArgumentException {
		//all calls are O(1) and there are no loops
		InnerEdge<E> edge = validate(e);
		Vertex<V>[] verts = edge.GetEndpoints();
		InnerVertex<V> vert1=validate(verts[0]);
		InnerVertex<V> vert2=validate(verts[1]);
		vert1.getOutgoing().remove(verts[1]);
		if(!directed)//only run the second remove if undirected. 
			vert2.getOutgoing().remove(verts[0]);
		edges.remove(edge.getPos());
		edge.setPos(null);
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#removeVertex(net.datastructures.Vertex)
	 */
	@TimeComplexity("O(deg(v))")
	public void removeVertex(Vertex<V> v) throws IllegalArgumentException {
		//all calls are O(1) and there are loops that run the the degree of V 
		InnerVertex<V> vert = validate(v);
		for(Edge<E> e : vert.getOutgoing().values())//remove all outgoing edges
			removeEdge(e);
		for(Edge<E> e : vert.getIncoming().values())//remove all incoming edges
			removeEdge(e);
		vertices.remove(vert.getPos());
		vert.setPos(null);
	}

	/* 
     * replace the element in edge object, return the old element
     */
	@TimeComplexity("O(1)")
	public E replace(Edge<E> e, E o) throws IllegalArgumentException {
		InnerEdge<E> edge  =(InnerEdge<E>)e;
		E old=edge.getElement();
		edge.setElement(o);
		return old;

	}

    /* 
     * replace the element in vertex object, return the old element
     */
	@TimeComplexity("O(1)")
	public V replace(Vertex<V> v, V o) throws IllegalArgumentException {
		//all calls are O(1) and there are no loops
		InnerVertex<V> vert1 = validate(v);
		V old = vert1.getElement();
		vert1.setElem(o);
		return old;
		
	}

	/* (non-Javadoc)
	 * @see net.datastructures.Graph#vertices()
	 */
	@TimeComplexity("O(1)")
	public Iterable<Vertex<V>> vertices() {
		return vertices;
	}

	@Override
	@TimeComplexity("O(1)")
	public int outDegree(Vertex<V> v) throws IllegalArgumentException {
		   InnerVertex<V> vert = validate(v);
		    return vert.getOutgoing().size();
	}

	@Override
	@TimeComplexity("O(1)")
	public int inDegree(Vertex<V> v) throws IllegalArgumentException {
		   InnerVertex<V> vert = validate(v);
		    return vert.getIncoming().size();
	}

	@Override
	@TimeComplexity("O(1)")
	public Iterable<Edge<E>> outgoingEdges(Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
    	return vert.getOutgoing().values();
	}

	@Override
	@TimeComplexity("O(1)")
	public Iterable<Edge<E>> incomingEdges(Vertex<V> v)
			throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
    	return vert.getIncoming().values();
	}

	@Override
	@TimeComplexity("O(1)")
	public Edge<E> getEdge(Vertex<V> u, Vertex<V> v)
			throws IllegalArgumentException {
		InnerVertex<V> vert = validate(u);
		return vert.getOutgoing().get(v);
	}
	
}
