package cs2321;
import java.util.Iterator;

import net.datastructures.Position;
import net.datastructures.PositionalList;


/**
 * The Class DoublyLinkedList.
 *
 * @param <E> the element type
 */
public class DoublyLinkedList<E> implements PositionalList<E> {
	
	/** The size of the data stored in the list. */
	private int size=0;
	
	/** The head node. */
	private Node<E> head;
	
	/** The tail node. */
	private Node<E> tail;
	
	/**
	 * The Class for a  Node.
	 *
	 * @param <E> the element type
	 */
	@SuppressWarnings("hiding")
	protected class Node<E> implements Position<E>{
		
		/** The next node in the list. */
		private Node<E> next;
		
		/** The Previous node in the list . */
		private Node<E> Prev;
		
		/** The element stored in the node. */
		private E element;
		
		/**
		 * Gets the element.
		 *
		 * @return the element of the node
		 * @throws IllegalStateException the illegal state exception
		 */
		@Override
		
		public E getElement() throws IllegalStateException {
			if(next==null)
				return null;
			return element;
		}
		
		/**
		 * Instantiates a new node.
		 *
		 * @param element the element
		 * @param prev the Previous node to the one being added
		 * @param next the node thats next to the node being added
		 */
		public Node(E element,Node<E> prev, Node<E> next) {
			this.element = element;
			Prev = prev;
			this.next = next;
		}

		/**
		 * Gets the next node.
		 *
		 * @return the next node
		 */
		public Node<E> getNext() {
			return next;
		}
		
		/**
		 * Sets the next node.
		 *
		 * @param next the new node that should be set as next
		 */
		public void setNext(Node<E> next) {
			this.next = next;
		}
		
		/**
		 * Gets the previous node.
		 *
		 * @return the previous node
		 */
		public Node<E> getPrev() {
			return Prev;
		}
		
		/**
		 * Sets the previous.
		 *
		 * @param prev the new previous to add
		 */
		public void setPrev(Node<E> prev) {
			Prev = prev;
		}
		
		/**
		 * Sets the element.
		 *
		 * @param element the new element
		 */
		@SuppressWarnings("unused")
		public void setElement(E element) {
			this.element = element;
		}
		
	}
	
	/**
	 * Val.
	 * changes from type of Position to a node while checking if its safe to do so
	 *
	 * @param p the p
	 * @return the node
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	protected Node<E> val (Position<E> p)  throws IllegalArgumentException {
	if (!(p instanceof Node))//check if the Position is a also a node
		throw new  IllegalArgumentException(); 
	Node<E> node =(Node<E>)p;
	if(node.getNext()==null)//check if the node is removed.
		throw new  IllegalArgumentException();
	return node;
	}
	
	/**
	 * Position
	 * checks if the node is a valid position
	 *
	 * @param node the node
	 * @return the position
	 */
	private Position<E> position(Node<E> node){
		if(node == head || node ==tail) 
			return null;
		return node;
	}
	
	/**
	 * Instantiates a new doubly linked list.
	 */
	public DoublyLinkedList() {
		head= new Node<>(null,null,null);
		tail= new Node<>(null,head,null);
		head.setNext(tail);
	}

	/**
	 * Size.
	 *
	 * @return the size of the data in the list
	 */
	@Override
	public int size() {
		return(size);
	}

	/**
	 * Checks if is empty.
	 *
	 * @return true, if is empty
	 */
	@Override
	public boolean isEmpty() {
		return (size==0);
	}

	/**
	 * First.
	 *
	 * @return the first position
	 */
	@Override
	public Position<E> first() {
		return(position(head.getNext()));
	}

	/**
	 * Last.
	 *
	 * @return the last position
	 */
	@Override
	public Position<E> last() {
		return(position(tail.getPrev()));
	}

	/**
	 * Before.
	 *
	 * @param p the position to get the Position that is  before it
	 * @return the position thats before the 
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	@Override
	public Position<E> before(Position<E> p) throws IllegalArgumentException {
		return (position(val(p).getPrev()));
	}

	/**
	 * After.
	 *
	 * @param p the position to get what's after it.
	 * @return the pos after p
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	@Override
	public Position<E> after(Position<E> p) throws IllegalArgumentException {
		return (position(val(p).getNext()));
	}


	/**
	 * Addbtw.
	 * Add Between two nodes
	 * @param e the e
	 * @param pred the first node
	 * @param suc the second node
	 * @return the position of the new node
	 */
	public Position<E> addbtw(E e ,Node<E> pred, Node<E> suc){
		Node<E> newNode = new Node<>(e,pred,suc);
		pred.setNext(newNode);
		suc.setPrev(newNode);
		size++;
		return newNode;
	}
	
	/**
	 * Adds the first.
	 *
	 * @param e the e
	 * @return the position
	 */
	@Override
	public Position<E> addFirst(E e) {

		return addbtw(e,head,head.getNext()); 
	}
	
	/**
	 * Adds the new node to the last index of the list.
	 *
	 * @param e the e
	 * @return the position
	 */
	@Override
	public Position<E> addLast(E e) {	
		return addbtw(e,tail.getPrev(),tail);
	}

	/**
	 * Adds the new node before the position in the list.
	 *
	 * @param p the position to add before
	 * @param e the the Element to add
	 * @return the position of the new node
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	@Override
	public Position<E> addBefore(Position<E> p, E e)
			throws IllegalArgumentException {
		Node<E> node =val(p);
		return addbtw(e,node.getPrev(),node);
	}

	/**
	 * Adds the node after the position.
	 *
	 * @param p the position to add before
	 * @param e the the Element to add
	 * @return the position of the new node
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	@Override
	public Position<E> addAfter(Position<E> p, E e)
			throws IllegalArgumentException {
		Node<E> node =val(p);
		return addbtw(e,node,node.getNext());
	}

	/**
	 * Sets the value of the node to a new element .
	 *
	 * @param p the position to set the new value to
	 * @param e the e the new value 
	 * @return the old value
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	@Override
	public E set(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> node =val(p);
		E elm = node.getElement();
		
		return elm;
	}
	

	/**
	 * Removes the positions from the list.
	 *
	 * @param p the position to remove
	 * @return the value of the position that is removed.
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	@Override
	public E remove(Position<E> p) throws IllegalArgumentException {
		Node<E> node =val(p);
		node.getPrev().setNext(node.getNext());
		node.getNext().setPrev(node.getPrev());
		size--;
		return node.getElement();
	}

	/**
	 * The Class PosI.
	 */
	private class PosI implements Iterator<Position<E>>{
		
		/** The current position of the iterator. */
		private Position<E> curr = first();
		
		/** The old position of the iterator */
		private Position<E> old = null;
		
		/**
		 * Checks if there is a next item in the iterator.
		 *
		 * @return true, if successful
		 */
		@Override
		public boolean hasNext() {
			return curr!=null;
		}

		/**
		 * Next.
		 * movies the iterator to the next value
		 * @return the position of the new iterator
		 * @throws IllegalStateException the illegal state exception
		 */
		@Override
		public Position<E>  next() throws  IllegalStateException{
			if(curr== null) {
				 throw new  IllegalStateException();// if the current node is null it can't move to the next node
			}
			old=curr; //saves the old position
			curr=after(curr);
			return old;
		}
		
		/**
		 * Removes the last value of the iterator from the list.
		 *
		 * @throws IllegalStateException the illegal state exception
		 */
		public void remove() throws IllegalStateException{
			if(old==null)
				throw new IllegalStateException();
			DoublyLinkedList.this.remove(old);//removes the last value of the iterator from the list.
			old=null;
		}
		
	
	}
	
	/**
	 * The warper class for PosI
	 */
	private class PosBle implements Iterable<Position<E>>{

		/**
		 * Iterator.
		 *
		 * @return the iterator
		 */
		@Override
		public Iterator<Position<E>> iterator() {
			return (Iterator<Position<E>>) new PosI();
		}
		
	}
	
	/**
	 * The warper Class for PosI.
	 */
	private class Eleme implements Iterator<E>{
		
		/** The pos it. */
		Iterator<Position<E>> posIt = new PosI();

		/**
		 * Checks for next.
		 *
		 * @return true, if successful
		 */
		@Override
		public boolean hasNext() {
			return posIt.hasNext();
		}

		/**
		 * Next.
		 *
		 * @return the e
		 */
		@Override
		public E next() {
			return posIt.next().getElement();
		}
		
		/**
		 * Removes the.
		 */
		public void remove() {
			posIt.remove();
		}
		
	}
	
	/**
	 * Iterator.
	 *
	 * @return the iterator for the list with elements
	 */
	@Override
	public Iterator<E> iterator() {
		return new Eleme();
	}

	/**
	 * Positions.
	 *
	 * @return the iterator for the list as positions 
	 */
	@Override
	public Iterable<Position<E>> positions() {
		return  new PosBle(); 
	}
	
	/**
	 * Removes the first element of the list.
	 *
	 * @return the e
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	public E removeFirst() throws IllegalArgumentException {
		return remove(position(head.getNext()));
	}
	
	/**
	 * Removes the last element of the list.
	 *
	 * @return the e
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	public E removeLast() throws IllegalArgumentException {
		return remove(position(tail.getPrev()));
	}

}
