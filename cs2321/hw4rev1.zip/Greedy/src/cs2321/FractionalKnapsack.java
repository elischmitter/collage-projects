package cs2321;

/**
 * @author:
 *
 */
public class FractionalKnapsack {

	private static int findMaxindex(int[][] items) {
		double mVal = ((double)items[0][1])/items[0][0];
		int index=0;
		for(int i =0 ;i< items.length; i++) {
			if (((double)items[i][1])/items[i][0]>mVal) {
				mVal=items[i][1]/items[i][0];
				index=i;
			}
		}
		return index;
	}
	/**
	 * Goal: Choose items with maximum total benefit but with weight at most W.
	 *       You are allowed to take fractional amounts from items.
	 *       
	 * @param items items[i][0] is weight for item i
	 *              items[i][1] is benefit for item i
	 * @param knapsackWeight
	 * @return The maximum total benefit. Please use double type operation. For example 5/2 = 2.5
	 * 		 
	 */
	public static double MaximumValue(int[][] items, int knapsackWeight) {
		double total =0;
		double totalWeight=0;
		while(totalWeight<=knapsackWeight) {
			int index=findMaxindex(items);
			if (totalWeight+items[index][0]<=knapsackWeight) {
				total+=(items[index][1]);
				totalWeight+=items[index][0];
				items[index][1]=0;
			}else {
				double frac = (knapsackWeight- totalWeight)/items[index][0];
				total+= frac * items[index][1];
				totalWeight=knapsackWeight;
				break;
			}
		}
		return total; 
	}
	
}
