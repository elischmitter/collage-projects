package cs2321;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class FractionalKnapsackTest {

	@Before
	public void setUp() throws Exception {
		
	}

	@Test
	public void testMaximumValue() {
		int[][] items = {{4,12},{8,32},{2,40},{6,30},{1,50}};
		double i =FractionalKnapsack.MaximumValue(items,10);
		assertEquals((double)124,i,.1); // TODO
	}

}
