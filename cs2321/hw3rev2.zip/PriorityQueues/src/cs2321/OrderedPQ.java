package cs2321;

import java.util.Comparator;

import net.datastructures.*;


/**
 * A PriorityQueue based on an ordered Doubly Linked List. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 *
 * @author 
 * @param <K> the key type
 * @param <V> the value type
 */

public class OrderedPQ<K,V> implements PriorityQueue<K,V> {
	
	/** The comparator. */
	private Comparator<K> comp;
	
	/** The list. */
	private DoublyLinkedList<Entry<K,V>> list = new DoublyLinkedList<>();
	
	/**
	 * Check key to see if its valid.
	 *
	 * @param k the key to check
	 * @return true, if successful
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	@TimeComplexity("O(1)")
	private boolean checkKey(K k) throws  IllegalArgumentException {
		try {
			return(comp.compare(k, k)==0);
		}catch(ClassCastException e){
			throw new IllegalArgumentException();
		}
	}
	
	/**
	 * Instantiates a new ordered PQ.
	 */
	public OrderedPQ() {
		this(new DefaultComparator<K>());
	}
	
	/**
	 * Instantiates a new ordered PQ.
	 *
	 * @param c the Comparator
	 */
	public OrderedPQ(Comparator<K> c) {
		comp=c;
	}
	
	/**
	 * Size.
	 *
	 * @return the size of the list
	 */
	@Override
	@TimeComplexity("O(1)")
	public int size() {
	return list.size();
	}

	/**
	 * Checks if is empty.
	 *
	 * @return true, if is empty
	 */
	@Override
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		return list.isEmpty();
	}

	/**
	 * Insert.
	 *
	 * @param key the key to be added 
	 * @param value the value to be added 
	 * @return the new added value
	 * @throws IllegalArgumentException the illegal argument exception
	 */
	@Override
	@TimeComplexity("O(n)")
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		//places where it fits in order so it must loop n times 
		checkKey(key);// is the key valid
		Entry <K,V> newE = new PQEntry<>(key,value);
		Position<Entry<K,V>> pos = list.last();
		while(pos != null && comp.compare(newE.getKey(), pos.getElement().getKey())<0) {
			pos=list.before(pos);
		}
		if(pos==null) {
			list.addFirst(newE);
		}
		else {
			list.addAfter(pos, newE);
		}
		return newE;
	}

	/**
	 * Gets the min value.
	 *returns null if empty
	 * @return the min entry
	 */
	@Override
	@TimeComplexity("O(1)")
	public Entry<K, V> min() {
		if(list.isEmpty()) {// see if there even is a min
			return null;
		}
		return  list.first().getElement();
	}

	/**
	 * Removes the min value.
	 * returns null if empty
	 * @return the entry
	 */
	@Override
	@TimeComplexity("O(1)")
	public Entry<K, V> removeMin() {
		if(list.isEmpty()) {
			return null;
		}
		return  list.removeFirst();
	}

}
