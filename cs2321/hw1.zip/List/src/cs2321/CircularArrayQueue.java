/**
 * 
 */
package cs2321;

import net.datastructures.Queue;

/**
 * @author ruihong-adm
 * @param <E>
 *
 */

public class CircularArrayQueue<E> implements Queue<E> {
	private E[] data;
	private int size = 0;
	private int front=0;
	public int lenght =0;
	public CircularArrayQueue(int queueSize) {
		data = (E[]) new Object[queueSize];
		lenght=queueSize;
	}
	
	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
	return size==0;
	}

	@Override
	public void enqueue(E e) {
		data[(front+size) % lenght ]= e;
		size+=1;
		
	}

	@Override
	public E first() {
		if (isEmpty())
			return null;
		return data[front];
	}

	@Override
	public E dequeue() {
		if(isEmpty())
			return null;
		E ret = data[front];
		data[front]=null;
		front=(front+1)%lenght;
		size-=1;
		return ret;
	}
    
}
