package cs2321;

import java.util.Comparator;

import net.datastructures.*;
/**
 * A Adaptable PriorityQueue based on an heap. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author
 */

public class HeapPQ<K,V> implements AdaptablePriorityQueue<K,V> {
	protected static class APQEntry<K,V> extends PQEntry<K,V>{
		private int index;
		public APQEntry(K key, V value, int j) { 
			super(key, value);
			index=j;
		}
		public int getIndex() {
			return index;
		}
		public void setIndex(int index) {
			this.index = index;
		}
	}
	private Comparator<K> comp;
	private ArrayList<Entry<K,V>> heap = new ArrayList<>();
	private int parent(int j) {
		return (j-1)/2;
	}
	private int left(int j) {
		return 2*j+1;
	}
	private int right(int j) {
		return 2*j + 2;
	}
	private boolean hasLeft(int j) { 
		return left(j) < heap.size(); 
		} 
	private boolean hasRight(int j) { 
		return right(j) < heap.size();
		}
	
	private boolean checkKey(K k) throws  IllegalArgumentException {
		try {
			return(comp.compare(k, k)==0);
		}catch(ClassCastException e){
			throw new IllegalArgumentException();
		}
	}
	public HeapPQ() {
		this(new DefaultComparator<K>());
	}
	
	public HeapPQ(Comparator<K> c) {
		comp=c;
	}
	
	private void swap(int i, int j) {
		Entry<K,V> temp = heap.get(i);
		heap.set(i, heap.get(j));
		heap.set(j, temp);
		((APQEntry<K,V>)heap.get(i)).setIndex(j); 
		((APQEntry<K,V>)heap.get(j)).setIndex(i); 
	}
	/**
	 * The entry should be bubbled up to its appropriate position 
	 * @param int move the entry at index j higher if necessary, to restore the heap property
	 */
	public void upheap(int j){
		while(j>0) {
			int p = parent(j);
			if(comp.compare(heap.get(j).getKey(),heap.get(p).getKey())>=0){
				break;
			}
			swap(j,p);
			j=p;
		}
	}
	
	/**
	 * The entry should be bubbled down to its appropriate position 
	 * @param int move the entry at index j lower if necessary, to restore the heap property
	 */
	
	public void downheap(int j){
		while(hasLeft(j)) {
			int min = left(j);
			if(hasRight(j)) {
				if (comp.compare(heap.get(left(j)).getKey(),heap.get(right(j)).getKey())>=0){
					min=right(j);
				}
			}
			if(comp.compare(heap.get(min).getKey(), heap.get(j).getKey())>=0) {
				break;
			}
			swap(j,min);
			j=min;
		}
	}

	@Override
	public int size() {
		return heap.size();
	}

	@Override
	public boolean isEmpty() {
		return heap.isEmpty();
	}

	@Override
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		checkKey(key);
		Entry<K,V>newE = new APQEntry<>(key,value,heap.size());
		heap.add(heap.size(),newE);
		upheap(heap.size()-1);
		return newE;
	}

	@Override
	public Entry<K, V> min() {
		if(heap.isEmpty()) {
			return null;
		}
		return heap.get(0);
	}

	@Override
	public Entry<K, V> removeMin() {
		if(heap.isEmpty()) {
			return null;
		}
		Entry<K,V> min= heap.get(0);
		swap(0,heap.size()-1);
		heap.remove(heap.size()-1);
		downheap(0);
		return min;
	}
	 void bubble(int j) {
		 if (j > 0 && comp.compare(heap.get(j).getKey(), heap.get(parent(j)).getKey()) < 0) {
		 upheap(j);
		 }
	 else {
		 downheap(j); // although it might not need to move 47 } 
	 	}	
	 }
	public APQEntry<K,V> check(Entry<K,V> e){
		if(!(e instanceof APQEntry)) {
				throw new IllegalArgumentException();
		}
		 APQEntry<K,V> x = (APQEntry<K,V>) e;
		 int j = x.getIndex();
		 if (j >= heap.size() || comp.compare(heap.get(j).getKey(),x.getKey())>0) {
			 throw new IllegalArgumentException(); 
		 }
		 return x;
	}
	@Override
	public void remove(Entry<K, V> entry) throws IllegalArgumentException {
		APQEntry<K,V> x = check(entry);
		if(x.getIndex()==heap.size()-1) {
			heap.remove(heap.size()-1);
		}
		else {
			swap(x.getIndex(),heap.size());
			heap.removeLast();
			bubble(x.getIndex());
		}
	}

	@Override
	public void replaceKey(Entry<K, V> entry, K key) throws IllegalArgumentException {
		APQEntry<K, V> e = check(entry);
		checkKey(e.getKey());
		e.setKey(key);
		bubble(e.getIndex());
	}

	@Override
	public void replaceValue(Entry<K, V> entry, V value) throws IllegalArgumentException {
		APQEntry<K, V> e = check(entry);
		e.setValue(value);
	}
	
	


}
