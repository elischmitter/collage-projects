package cs2321;

import java.util.Comparator;

import net.datastructures.*;
/**
 * A PriorityQueue based on an ordered Doubly Linked List. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author
 */

public class OrderedPQ<K,V> implements PriorityQueue<K,V> {
	private Comparator<K> comp;
	private DoublyLinkedList<Entry<K,V>> list = new DoublyLinkedList<>();
	
	@TimeComplexity("O(1)")
	private boolean checkKey(K k) throws  IllegalArgumentException {
		try {
			return(comp.compare(k, k)==0);
		}catch(ClassCastException e){
			throw new IllegalArgumentException();
		}
	}
	
	public OrderedPQ() {
		this(new DefaultComparator<K>());
	}
	
	public OrderedPQ(Comparator<K> c) {
		comp=c;
	}
	
	@Override
	public int size() {
	return list.size();
	}

	@Override
	public boolean isEmpty() {
		return list.isEmpty();
	}

	@Override
	@TimeComplexity("O(n)")
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		checkKey(key);
		Entry <K,V> newE = new PQEntry<>(key,value);
		Position<Entry<K,V>> pos = list.last();
		while(pos != null && comp.compare(newE.getKey(), pos.getElement().getKey())<0) {
			pos=list.before(pos);
		}
		if(pos==null) {
			list.addFirst(newE);
		}
		else {
			list.addAfter(pos, newE);
		}
		return newE;
	}

	@Override
	@TimeComplexity("O(1)")
	public Entry<K, V> min() {
		if(list.isEmpty()) {
			return null;
		}
		return  list.first().getElement();
	}

	@Override
	@TimeComplexity("O(1)")
	public Entry<K, V> removeMin() {
		if(list.isEmpty()) {
			return null;
		}
		return  list.removeFirst();
	}

}
