package cs2321;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import net.datastructures.Entry;
import net.datastructures.PriorityQueue;

public class OrderedPQTest {
	PriorityQueue<String, Integer> ordpq;
	
	@Before
	public void setUp() throws Exception {
		ordpq = new UnorderedPQ<String, Integer>();
		ordpq.insert("Bulbous Bouffant", 16);
		ordpq.insert("Gazebo", 6);
		ordpq.insert("Balooga", 7);
		ordpq.insert("Galoshes", 8);
		ordpq.insert("Eskimo", 6);
		ordpq.insert("Mukluks", 7);
		ordpq.insert("Macadamia", 9);
	}

	@Test
	public void testSize() {
		assertEquals(ordpq.size(),7);
	}

	@Test
	public void testIsEmpty() {
		while(!ordpq.isEmpty()) {
			ordpq.removeMin();
		}
		assertEquals(ordpq.size(),0);
	}

	@Test
	public void testInsert() {
		PriorityQueue<String, Integer> ordpq2 = new UnorderedPQ<String, Integer>();
		assertEquals(ordpq2.size(),0);
		ordpq2.insert("Bulbous Bouffant", 16);
		assertEquals(ordpq2.min().getValue(),new PQEntry<String,Integer>("Bulbous Bouffant", 16).getValue());
		assertEquals(ordpq2.min().getKey(),new PQEntry<String,Integer>("Bulbous Bouffant", 16).getKey());
		assertEquals(ordpq2.size(),1);	
		}

	@Test
	public void testMin() {
		Entry<String, Integer> e;
		String[] expected= {
				"Balooga", 
				"Bulbous Bouffant",
				"Eskimo", 
				"Galoshes", 
				"Gazebo", 
				"Macadamia",
				"Mukluks"
		};
		
		int i=0;
		while(!ordpq.isEmpty()){
			e = ordpq.min();
			assertEquals(expected[i],  e.getKey());
			i++;
			ordpq.removeMin();
		}
	}

	@Test
	public void testRemoveMin() {
		Entry<String, Integer> e;
		String[] expected= {
				"Balooga", 
				"Bulbous Bouffant",
				"Eskimo", 
				"Galoshes", 
				"Gazebo", 
				"Macadamia",
				"Mukluks"
		};
		
		int i=0;
		while(!ordpq.isEmpty()){
			e = ordpq.removeMin();
			assertEquals(expected[i],  e.getKey());
			i++;
		}
	}
}
