package cs2321;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import net.datastructures.AdaptablePriorityQueue;
import net.datastructures.Entry;
import net.datastructures.PriorityQueue;

public class HeapPQTest {

	AdaptablePriorityQueue<String, Integer> heappq;
	
	@Before
	public void setUp() throws Exception {
		heappq = new HeapPQ<String, Integer>();
		heappq.insert("Bulbous Bouffant", 16);
		heappq.insert("Gazebo", 6);
		heappq.insert("Balooga", 7);
		heappq.insert("Galoshes", 8);
		heappq.insert("Eskimo", 6);
		heappq.insert("Mukluks", 7);
		heappq.insert("Macadamia", 9);
	}

	@Test
	public void testRemoveMin() {
		Entry<String, Integer> e;
		String[] expected= {
				"Balooga", 
				"Bulbous Bouffant",
				"Eskimo", 
				"Galoshes", 
				"Gazebo", 
				"Macadamia",
				"Mukluks"
		};
		
		int i=0;
		while(!heappq.isEmpty()){
			e = heappq.removeMin();
			assertEquals(expected[i],  e.getKey());
			i++;
		}
	}

	@Test
	public void testSize() {
		assertEquals(heappq.size(),7);
	}

	@Test
	public void testIsEmpty() {
		while(!heappq.isEmpty()) {
			heappq.removeMin();
		}
		assertEquals(heappq.size(),0);
	}

	@Test
	public void testInsert() {
		PriorityQueue<String, Integer> heappq2 = new UnorderedPQ<String, Integer>();
		assertEquals(heappq2.size(),0);
		heappq2.insert("Bulbous Bouffant", 16);
		assertEquals(heappq2.min().getValue(),new PQEntry<String,Integer>("Bulbous Bouffant", 16).getValue());
		assertEquals(heappq2.min().getKey(),new PQEntry<String,Integer>("Bulbous Bouffant", 16).getKey());
		assertEquals(heappq2.size(),1);	
		heappq2.insert("Balooga", 7);
		assertEquals(heappq2.min().getValue(),new PQEntry<String,Integer>("Balooga", 7).getValue());
		assertEquals(heappq2.min().getKey(),new PQEntry<String,Integer>("Balooga", 7).getKey());
		assertEquals(heappq2.size(),2);	
		}

	@Test
	public void testMin() {
		Entry<String, Integer> e;
		String[] expected= {
				"Balooga", 
				"Bulbous Bouffant",
				"Eskimo", 
				"Galoshes", 
				"Gazebo", 
				"Macadamia",
				"Mukluks"
		};
		
		int i=0;
		while(!heappq.isEmpty()){
			e = heappq.min();
			assertEquals(expected[i],  e.getKey());
			i++;
			heappq.removeMin();
		}
	}


	@Test

	public void testRemove() {
		Entry<String, Integer> e;
		String[] expected= {
				"Balooga", 
				"Bulbous Bouffant",
				"Eskimo", 
				"Galoshes", 
				"Gazebo",
				"Mukluks"
		};
		int i=0;
		heappq.remove(new HeapPQ.APQEntry<String, Integer> ("Macadamia", 9,6));
		while(!heappq.isEmpty()){
			e = heappq.min();
			assertEquals(expected[i],  e.getKey());
			i++;
			heappq.removeMin();
		}
	}

	@Test
	
	public void testReplaceKey() {
		String[] expected= {
				"Balooga", 
				"Bulbous Bouffant",
				"Eskimo", 
				"Galoshes", 
				"Gazebo", 
				"bill",
				"Mukluks"
		};
		Entry<String, Integer> b = new HeapPQ.APQEntry<String, Integer> ("Macadamia", 9,6);
		heappq.replaceKey(b, "bill");
		int i =0;
		Entry<String, Integer> x;
		while(!heappq.isEmpty()){
			x = heappq.min();
			assertEquals(expected[i],  x.getKey());
			i++;
			heappq.removeMin();
		}
	}

	@Test
	public void testReplaceValue() {
		String[] expected= {
				"Balooga", 
				"Bulbous Bouffant",
				"Eskimo", 
				"Galoshes", 
				"Gazebo", 
				"bill",
				"Mukluks"
		};
		Entry<String, Integer> b = new HeapPQ.APQEntry<String, Integer> ("Macadamia", 9,6);
		heappq.replaceKey(b, "bill");
		int i =0;
		Entry<String, Integer> x;
		while(!heappq.isEmpty()){
			x = heappq.min();
		//	assertEquals(expected[i],  x.getValue()());
			i++;
			heappq.removeMin();
		}
	}

}
