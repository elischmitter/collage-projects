package cs2321;

import java.util.Comparator;

import net.datastructures.*;
/**
 * A PriorityQueue based on an Unordered Doubly Linked List. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author
 */

public class UnorderedPQ<K,V> implements PriorityQueue<K,V> {
	private Comparator<K> comp;
	private DoublyLinkedList<Entry<K,V>> list = new DoublyLinkedList<>();
	@TimeComplexity("O(n)")
	private Position<Entry<K,V>> findMin() {
		Position<Entry<K,V>> small = list.first();
		for(Position<Entry<K, V>> i:list.positions()) {
			if(comp.compare(small.getElement().getKey(),i.getElement().getKey())>0) {
				small=i;
			}
		}
		return small;
	}
	@TimeComplexity("O(1)")
	private boolean checkKey(K k) throws  IllegalArgumentException {
		try {
			return(comp.compare(k, k)==0);
		}catch(ClassCastException e){
			throw new IllegalArgumentException();
		}
	}

	
	public UnorderedPQ() {
		this(new DefaultComparator<K>());
	}

	
	public UnorderedPQ(Comparator<K> c) {
			comp=c;
	}

	@Override
	@TimeComplexity("O(1)")
	public int size() {
		return list.size();
	}

	@Override
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		return list.isEmpty();
	}

	@Override
	@TimeComplexity("O(1)")
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
	//constant time becuse all the functan calls are of time O("1")
		checkKey(key);
		Entry<K,V> newE = new PQEntry<>(key,value);
		list.addLast(newE);
		return newE;
	}

	@Override
	@TimeComplexity("O(n)")
	public Entry<K, V> min() {
	//has n time because of the findMin function call
		if(isEmpty()) {
			return null;
		}
		return findMin().getElement();
	}

	@Override  
	@TimeComplexity("O(n)")
	public Entry<K, V> removeMin() {
		//has n time because of the findMin function call
		if (isEmpty()) {
			return null;
		}
		return list.remove(findMin());
	}
	
	

}
