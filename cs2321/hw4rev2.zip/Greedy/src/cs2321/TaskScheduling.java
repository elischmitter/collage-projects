package cs2321;

// TODO: Auto-generated Javadoc
/**
 * The Class TaskScheduling.
 */
public class TaskScheduling {
	
/**
 *  sees if there is a place to run the program
 *
 * @param i the start value of the new presses
 * @param x the ArrayList of Machines 
 * @return true, if successful
 */
private static boolean lessthen(int i,ArrayList<int[]> x) {
		Boolean flag=false;
		for (int[] j:x) {
			flag = (i>=j[1]) ? true: flag ;
	}
		return flag;
	}
	/**	
	 * Goal: Perform all the tasks using a minimum number of machines. 
	 * 
	 *       
	 * @param tasks tasks[i][0] is start time for task i
	 *              tasks[i][1] is end time for task i
	 * @return The minimum number or machines
	 * 
	 */

   public static int NumOfMachines(int[][] tasks) {
	   HeapPQ<Integer,int[]> pq = new HeapPQ<>();
	   for(int currTask =0; currTask<tasks.length;currTask++) {//put all of the items in a pq
		   pq.insert(tasks[currTask][0],tasks[currTask]);
	   }
	   ArrayList<int[]> Machines= new ArrayList<>();
	   int numberMachiens=0;
	   int lastEnd=0;
	 
	   while(!pq.isEmpty()) {
		   	int[] i = pq.removeMin().getValue();		   	
		   	if(!lessthen(i[0],Machines)) {//see if you can run the task
		   		Machines.addLast(i); // ad Machine if you can't
		   	}
	   }
	   return Machines.size();
   }
}
