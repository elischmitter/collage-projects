package cs2321;

/**
 * The Class FractionalKnapsack.
 *
 * @author: 
 */
public class FractionalKnapsack {

	/**
	 * Find the index of the item with the max value.
	 *
	 * @param items the array of the items to find the index of the max value
	 * @return the index of the max value
	 */
	private static int findMaxindex(int[][] items) {
		double mVal = ((double)items[0][1])/items[0][0];// the max value so far 
		int index=0;
		for(int i =0 ;i< items.length; i++) {
			if (((double)items[i][1])/items[i][0]>mVal) {//see if there is a new max
				mVal=items[i][1]/items[i][0];
				index=i;
			}
		}
		return index;
	}
	
	/**
	 * Goal: Choose items with maximum total benefit but with weight at most W.
	 *       You are allowed to take fractional amounts from items.
	 *       
	 *
	 * @param items items[i][0] is weight for item i
	 *              items[i][1] is benefit for item i
	 * @param knapsackWeight the knapsack weight
	 * @return The maximum total benefit. Please use double type operation. For example 5/2 = 2.5
	 */
	public static double MaximumValue(int[][] items, int knapsackWeight) {
		double total =0;
		double totalWeight=0;
		while(totalWeight<=knapsackWeight) {
			int index=findMaxindex(items);
			if (totalWeight+items[index][0]<=knapsackWeight) {//see if knapsack is full
				total+=(items[index][1]);
				totalWeight+=items[index][0];
				items[index][1]=0;
			}else {
				double frac = (knapsackWeight- totalWeight)/items[index][0];//find the percent of the next item that can be added
				total+= frac * items[index][1];
				totalWeight=knapsackWeight;
				break;
			}
		}
		return total; 
	}
	
}
